# plans for noro development
[X] add theme support with inicxx
[X] add config
[ ] add vertical scrolling
[ ] add horizontal scrolling
[ ] add tabs
[ ] add new type of window
[ ] add settings menu
[ ] add plugin support
[ ] add customisable renderers
