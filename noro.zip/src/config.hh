#pragma once
#include "_components.hh"

struct AppConfig {
	uint8_t tabSize;
};
