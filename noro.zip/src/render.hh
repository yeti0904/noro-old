#pragma once
#include "_components.hh"

class EditorWindow;

namespace Renderers {
	namespace Noro {
		void Global();
		void RenderEditorWindow(EditorWindow& editorWindow);
	}
}
