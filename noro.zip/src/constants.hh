#pragma once

#define APP_NAME    "noro"
#define APP_VERSION "0.1.0"

#define ALERT_TIMER 3000
#define MAX_HISTORY 50
