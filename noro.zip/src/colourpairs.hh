#pragma once

#define COLOUR_PAIR_EDITOR   1
#define COLOUR_PAIR_TITLEBAR 2
