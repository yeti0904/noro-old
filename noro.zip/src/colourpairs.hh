#pragma once

#define COLOUR_PAIR_EDITOR    1
#define COLOUR_PAIR_TITLEBAR  2
#define COLOUR_PAIR_ALERT     3
#define COLOUR_PAIR_TABS      4
#define COLOUR_PAIR_ACTIVETAB 5
