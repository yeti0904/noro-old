#pragma once
#include "_components.hh"

struct Vec2 {
	size_t x, y;
};
