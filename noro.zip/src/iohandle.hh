#pragma once
#include "_components.hh"

namespace IOHandle {
	void Init();
	void Quit();
}
