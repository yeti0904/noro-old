#pragma once

namespace Terminal {
	void Run();
}
