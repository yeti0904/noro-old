# Changelog
All the versions and the changes they bring

## Inicxx
- `1.0.0`: Working INI file parser and writer
- `1.1.0`: README.md and makefile changes, using unordered_map instead of map
- `1.2.0`: README.md fixes, using std::cerr instead of std::cout in examples
- `1.2.1`: New logo
- `1.2.2`: Added more comments to inicxx.hh
- `1.2.3`: Removed no exceptions support (its only causing problems and bad code)
- `1.2.4`: Error fixes, DefaultSection moved to INI namespace
