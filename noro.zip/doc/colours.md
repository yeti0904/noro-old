# colours
noro supports up to 16 colours in theme files

## 8 colours
these colours will work in 8 colour terminals:
- black
- red
- green
- yellow
- blue
- magenta
- cyan
- white

## 16 colours
these colours will work in 16 colour terminals:
- black
- red
- green
- yellow
- blue
- magenta
- cyan
- white
- grey
- brightred
- brightgreen
- brightyellow
- brightblue
- brightmagenta
- brightcyan
- brightwhite

## default colour
the `default` colour will use your terminal's FG/BG colour
